﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProjectDatabace.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectDatabace.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Employee1> emdbset { get; set; }
        public DbSet<Deivion> devionsdbs { get; set; }
        public DbSet<mah> mahsdbs { get; set; }
    }
}
