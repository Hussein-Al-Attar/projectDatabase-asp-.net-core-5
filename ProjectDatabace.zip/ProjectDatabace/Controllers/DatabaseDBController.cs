﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjectDatabace.Data;
using ProjectDatabace.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectDatabace.Controllers
{
   // [Authorize]
    public class DatabaseDBController : Controller
    {

        private ApplicationDbContext db = null;
       
        public DatabaseDBController(ApplicationDbContext db)
        {
            this.db = db;

        }
        private void filldiv()
        {
            var devion = (from e in db.devionsdbs
                          orderby e.dviID
                          select new SelectListItem()
                          {
                              Text = e.divName,
                              Value = e.dviID.ToString()
                          }).ToList();
            ViewBag.Devition = devion;
        }
        [HttpGet]
  
        public IActionResult Create()
        {
            ViewBag.Dep_id = db.devionsdbs;
            ViewBag.mah_id = db.mahsdbs;
            filldiv();
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee1 emp)
        {
            if (ModelState.IsValid)
            {
                db.emdbset.Add(emp);
                db.SaveChanges();
                return RedirectToAction("index",db.emdbset);
            }
            return View();
        }
        [HttpGet]
        public IActionResult Details(int id)
        {
            Employee1 emp = db.emdbset.Find(id);
            var m = db.devionsdbs.Find(emp.emDivtionID);
            ViewBag.m = m.divName;
            var h = db.mahsdbs.Find(emp.empmahID);
            ViewBag.h = h.mahName;
            return View(emp);
        }
        [HttpGet]
        private void fill_type()
        {
            var T = (from e in db.devionsdbs
                     orderby e.dviID
                     select new SelectListItem()
                     {
                         Text = e.divName,
                         Value = e.dviID.ToString()
                     }).ToList();
            ViewBag.T = T;
            var h = (from e in db.mahsdbs
                     orderby e.mahId
                     select new SelectListItem()
                     {
                         Text = e.mahName,
                         Value = e.mahId.ToString()
                     }).ToList();
            ViewBag.h = h;
        }
        public IActionResult Edit(int id)
        {
           
            Employee1 emp = db.emdbset.Find(id);
            fill_type();
            return View(emp);
        }
        [HttpPost]
        public IActionResult Edit(Employee1 Edemp)
        {
            if (ModelState.IsValid)
            {

                db.emdbset.Update(Edemp);
                db.SaveChanges();
                return RedirectToAction("index", db.emdbset);

            }
           
            return View(Edemp);
        }
        [AllowAnonymous]
        public IActionResult Index()
        {
            var Emplist = db.emdbset.Include(a =>a.EmpDevion).Include(a => a.empMah);
            return View(Emplist);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            
            
            Employee1 emp = db.emdbset.Find(id);
            var m = db.devionsdbs.Find(emp.emDivtionID);
            ViewBag.T = m.divName;
            var h = db.mahsdbs.Find(emp.empmahID);
            ViewBag.h = h.mahName;
            return View(emp);
        }
        [ActionName("Delete")]
        [HttpPost]
        public IActionResult Delete1(int id)
        {
            Employee1 emp = db.emdbset.Find(id);
            db.emdbset.Remove(emp);
            db.SaveChanges();
            return View("index", db.emdbset);
        }
    }
}
