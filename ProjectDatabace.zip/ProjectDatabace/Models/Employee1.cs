﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectDatabace.Models
{
    [Table("WOrk_Table")]
    public class Employee1
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        [Display(Name = "الرقم التسلسلي")]
        public int Id { get; set; }
        [StringLength(10, MinimumLength = 3)]
        [Required(ErrorMessage = "لا تتركه فارغ")]

        [Display(Name = "الاسم الاول ")]
        //[RegularExpression(@"^[a-zA-Z ]+$")]
        [RegularExpression(@"^[\u0621-\u064A ]+$", ErrorMessage = "يجب ان تكون بلعربي ")]
        public string Name { get; set; }
        public string Pictur { get; set; }
      
        [Display(Name = "القسم")]
       
        public int emDivtionID { get; set; }
        [ForeignKey("emDivtionID")]
        public virtual Deivion EmpDevion { get; set; }
        [EmailAddress(ErrorMessage = "الايميل غير صحيح ")]
        public string emEmail { get; set; }
        
        [RegularExpression(@"^(\+\d{1,3}[- ]?)?\d{11}$")]
        [Display(Name = "رقم التليفون")]
        

        public string emPhon{ get; set; }
        [Required]
        public DateTime emBriyh { get; set; }
        public int empmahID { get; set; }
        [ForeignKey("empmahID")]
        public virtual mah empMah { get; set; }
        [StringLength(10, MinimumLength = 3)]
        [RegularExpression(@"[a-zA-Z1-9 ]+$")]

        public string notes { get; set; }
    }
}
